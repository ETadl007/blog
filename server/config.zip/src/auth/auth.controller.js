
/**
 *  验证登录
 */

export const validate = async (req, res, next) => {

    res.send({
        status: 0,
        message: "验证成功"
    });

}